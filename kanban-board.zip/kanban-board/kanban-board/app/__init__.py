from flask import Flask
from flask_sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)
db_path = os.path.join(os.path.dirname(__file__), 'app.db')
print(db_path)
URI = 'sqlite:///'+"./app/app.db"
app.config['SQLALCHEMY_DATABASE_URI'] = URI
app.config['DEBUG'] = True
app.config["SECRET_KEY"] = '\xfd{H\xe5<\x95\xf9\xe3\x96.5\xd1\x01O<!\xd5\xa2\xa0\x9fR"\xa1\xa8'
db = SQLAlchemy(app=app)



