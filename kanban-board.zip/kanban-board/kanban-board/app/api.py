from __init__ import db, app
from passlib.hash import sha256_crypt
from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from .models import User, Task
from jinja2 import  FileSystemLoader,Environment

templateLoader = Environment(loader=FileSystemLoader(searchpath='./templates'))

def set_password(password, salt):
    db_password = password+salt
    h = sha256_crypt.hash(db_password)
    return h

@app.route('/signup')
def sign_up_page():
    return render_template('signup.html')

@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/signup', methods=["POST"])
def create_user():
    user = db.session.query(User).filter(User.username==request.form['username']).first()
    if not user:
        user = User(
            username=request.form['username'],
            password=set_password(request.form['password'], request.form['username'])
        )
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('index'))
    else:
        flash('Username already existed!')
        return render_template('signup.html')

@app.route('/')
def index():
    if not session.get('username'):
        return redirect(url_for('login_page'))
    else:
        tasks = db.session.query(Task).filter(Task.username==session.get('username'))
        to_do, doing, done = [],[],[]
        for task in tasks:
            if task.status == 'to_do':
                to_do.append(task)
            elif task.status == 'doing':
                doing.append(task)
            elif task.status == 'done':
                done.append(task)
    return render_template('index.html', to_do=to_do, doing=doing, done=done, user=session.get('username'))

@app.route('/login', methods=['POST'])
def login():
    user = db.session.query(User).filter(User.username==request.form['username']).first()
    h = request.form['password']+request.form['username']
    if not user:
        flash('Invalid username!')
    elif sha256_crypt.verify(h, user.password):
        session['username'] = user.username
        flash('Logged in successfully!')
    else:
        flash('Incorrect password!')
    return redirect(url_for('index'))

@app.route('/logout')
def log_out():
    session.pop('username', None)
    flash('Logged out successfully!')
    return redirect(url_for('index'))

@app.route('/add', methods=['POST'])
def add():
    if not session.get('username'):
        abort(401)
    to_do = Task(
        username=session.get('username'),
        task=request.form['task'],
        status='to_do'
    )
    db.session.add(to_do)
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/task/<id>/<status>')
def change_status(id,status):
    if not session.get('username'):
        abort(401)
    task = db.session.query(Task).filter(Task.id==int(id)).first()
    if not task:
        abort(404)
    task.status = status
    db.session.commit()  
    return redirect(url_for('index'))

@app.route('/task/<id>', methods=['GET', 'POST', 'DELETE'])
def delete(id):
    if not session.get('username'):
        abort(401)
    task = db.session.query(Task).filter(Task.id==int(id)).first()
    if not task:
        abort(404)
    db.session.delete(task)
    db.session.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)